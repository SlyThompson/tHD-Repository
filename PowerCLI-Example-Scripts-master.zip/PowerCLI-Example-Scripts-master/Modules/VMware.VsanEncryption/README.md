Prerequisites/Steps to use this module:

1. This module only works for vSphere products that support vSAN Encryption. E.g. vSAN 6.6 and later with a vSAN Enterprise license
2. All the functions in this module only work for KMIP Servers.
3. Install the latest version of Powershell and PowerCLI(11).
4. Import this module by running: Import-Module -Name "location of this module"
5. Get-Command -Module "This module Name" to list all available functions.