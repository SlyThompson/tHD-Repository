# rCisTag

A module with cmdlets to provide CRUD functions to
* Tags
* Tag Categories
* Tag Assignments

The cmdlets use the Cis REST API

## History

* Author  : **Luc Dekens**
* Release :
	* **0.9.0**		First draft
	